import java.util.Scanner;
import java.util.regex.Matcher;
import java.lang.Object;
import java.util.Arrays;
public class Student {
    private String firstName;
    private String lastName;
    private int peopleSoft;
    private String classStanding;
    private String email;
    private String address;
    private String city;
    private String state;
    private int zipCode;
    private static int scount = 0;

    public void getValues() {
        System.out.println("\nEnter First name:");
        Scanner input = new Scanner(System.in);
        firstName = input.nextLine();
        while (!firstName.matches("[a-zA-Z]+")) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("\nEnter First name:");
            Scanner input2 = new Scanner(System.in);
            firstName = input2.nextLine();
        }


        System.out.println("Enter Last name:");
        lastName = input.nextLine();
        while (!lastName.matches("[a-zA-Z]+")) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("\nEnter Last name:");
            Scanner input2 = new Scanner(System.in);
            lastName = input2.nextLine();
        }

        //
        System.out.println("Enter PeopleSoft Id:");
        peopleSoft = input.nextInt();
        //input.nextLine();
        int peoplesoftlength = String.valueOf(peopleSoft).length();
        String peoplesoftstring = String.valueOf(peopleSoft);
        while (!(peoplesoftlength <= 7 || peoplesoftstring.matches("[0-9]"))) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("Enter PeopleSoft Id:");
            Scanner input3 = new Scanner(System.in);
            peopleSoft = input3.nextInt();
            peoplesoftlength = String.valueOf(peopleSoft).length();
        }


        //
        System.out.println("Enter Class Standing: Freshman,Sophomore,Junior or Senior");
        Scanner input4 = new Scanner(System.in);
        classStanding = input4.nextLine();

        while (!(classStanding.equals("freshmen") || classStanding.equals("sophomore") || classStanding.equals("junior") || classStanding.equals("senior"))) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("Enter Class Standing: Freshman,Sophomore,Junior or Senior");
            Scanner input5 = new Scanner(System.in);
            classStanding = input5.nextLine();

        }


        //
        System.out.println("Enter Email Id:");
        Scanner input6 = new Scanner(System.in);
        email = input6.nextLine();
        while (!email.matches("^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("\nEnter Email Id:");
            Scanner email1 = new Scanner(System.in);
            email = email1.nextLine();
        }


        //
        System.out.println("Enter Address:");
        Scanner input7 = new Scanner(System.in);
        address = input7.nextLine();


        while (!address.matches("^(?:[Pp][Oo]\\s[Bb][Oo][Xx]|[0-9]+)\\s(?:[0-9A-Za-z\\.'#]|[^\\S\\r\\n])+")) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("\nEnter Address:");
            Scanner address1 = new Scanner(System.in);
            address = address1.nextLine();
        }


        //
        System.out.println("Enter City:");
        Scanner input8 = new Scanner(System.in);
        city = input8.nextLine();

        while (!city.matches("[a-zA-Z]+")) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("\nEnter City:");
            Scanner input9 = new Scanner(System.in);
            city = input9.nextLine();
        }

        //
        System.out.println("Enter State:");
        Scanner input10 = new Scanner(System.in);
        state = input10.nextLine().toUpperCase();

        boolean firstloop=true;
        while(firstloop){
            String[]stateArray={"AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE",
                    "FL", "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA","MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND",
                    "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"};
            boolean check=Arrays.stream(stateArray).anyMatch(state::equals);
            while(!(check)){
                System.out.println("Invalid entry! Try again!");
                System.out.println("Enter State:");
                Scanner inputState = new Scanner(System.in);
                state = inputState.nextLine().toUpperCase();
                check=Arrays.stream(stateArray).anyMatch(state::equals);
            }
            break;
        }


        //
        System.out.println("Enter Zipcode:");
        Scanner input11 = new Scanner(System.in);
        zipCode = input11.nextInt();
        int zipcodelength = String.valueOf(zipCode).length();
        String zipcodestring = String.valueOf(zipCode);
        while (!(zipcodelength == 9 || zipcodestring.matches("[0-9]"))) {
            System.out.println("Invalid entry! Try again!");
            System.out.println("Enter Zipcode:");
            Scanner input12 = new Scanner(System.in);
            zipCode = input12.nextInt();
            zipcodelength = String.valueOf(zipCode).length();
            //input11.nextLine();
        }
    }
        public void displayValues () {
            System.out.println("Students Details, Department of ILT");
            System.out.println("First name: " + firstName);
            System.out.println("Last name: " + lastName);
            System.out.println("PeopleSoft Id: " + peopleSoft);
            System.out.println("Class Standing: " + classStanding);
            System.out.println("Email Id: " + email);
            System.out.println("Address line: " + address+ " "+city +" "+ state +" "+ zipCode);
            System.out.println("Number of students:" + Student.Count());
        }
        public static int Count () {
            scount = scount + 1;
            return scount;
        }


}
