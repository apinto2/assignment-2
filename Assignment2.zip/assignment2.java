import java.util.Scanner;
public class assignment2 {
    public static void main(String[] args){
        int N;
        Scanner input= new Scanner(System.in);
        System.out.println("How many students data do you want to enter:");
        N=input.nextInt();
        input.nextLine();
        Student[] s= new Student[N];
        for (int w=0; w<N; w++){
            s[w]=new Student();



            s[w].getValues();
            s[w].displayValues();
        }


    }
}
